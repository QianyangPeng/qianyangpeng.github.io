﻿VOCALOID · Model Y Juniper Premium · 20 款

适配 2026 普通焕新版 / Premium。仅用于 Tesla Toybox 数字车衣。
每张 PNG 1024×1024，小于 1 MB。它不是实体车贴的印刷施工文件。

单张导入：Tesla App 的 Creations → Wrap → Upload。
U 盘导入：将一个 USB 批次中的 Wraps 文件夹放到 U 盘根目录。
每次最多 10 张；换批次时替换 Wraps 中的图片，不要把多批次合在一起。
在车机 Toybox → Paint Shop → Wraps 中选择。App 和 USB 各最多 10 张。

制作包每个编号对应：concept.png 为 AI 整车概念效果，qa.png 为实际导出图检查页，
Wraps/ 下为可导入 PNG，source-master.png 和 sources/ 是原画与分侧稿。
prompts.json / source-refinements.json / concept-refinement.json 记录创作和修订，meta.json 记录设计主题。
概念图为 AI 展示。网站 3D 把外壳分为 20 个面板：四门等比展示同款原画的精确导出裁片，
不加官方轮廓蒙版，以保持人脸比例；其余装饰面板读取 PNG。下载文件仍是官方模板展开图。
社区模型的面板位置、接缝和曲面显示可能与车机不同，最终兼容性及效果需在车辆中确认。
AI 原画按实际生成尺寸保存，没有将低分辨率放大后宣称为原生高分辨率。

官方模板与导入说明：https://github.com/teslamotors/custom-wraps
在线预览：https://qianyangpeng.github.io/itasha/
个人非商业同人设计收藏，角色与品牌属于各自权利人。

VO01_MikuPearl — 初音未来 / 珠光咏叹
VO02_MikuOrchid — 初音未来 / 数字兰庭
VO03_MikuCrimson — 初音未来 / 绯红夜曲
VO04_MikuTide — 初音未来 / 天穹潮汐
VO05_RinRococo — 镜音铃 / 柑橘洛可可
VO06_RinSunburst — 镜音铃 / 朋克日耀
VO07_LenCadence — 镜音连 / 王室华彩乐章
VO08_LenTropic — 镜音连 / 热带电压
VO09_LukaQuartz — 巡音流歌 / 蔷薇晶梦
VO10_LukaAbyss — 巡音流歌 / 深渊蕾丝
VO11_KaitoPorcelain — KAITO / 青瓷狂想
VO12_KaitoGlacier — KAITO / 冰晶圣堂
VO13_MeikoSilk — MEIKO / 绯红锦绢
VO14_MeikoCabaret — MEIKO / 午夜歌舞
VO15_GumiEmerald — GUMI / 翡翠珍奇
VO16_GumiPrism — GUMI / 棱镜波普
VO17_IaIris — IA / 月下鸢尾
VO18_FlowerVelvet — v flower / 荆棘绒夜
VO19_LuoJade — 洛天依 / 玉境遐音
VO20_LingPhoenix — 乐正绫 / 绯羽凤鸣