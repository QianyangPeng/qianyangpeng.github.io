﻿原神 · Model Y Juniper Premium · 20 款

适配 2026 普通焕新版 / Premium。仅用于 Tesla Toybox 数字车衣。
每张 PNG 1024×1024，小于 1 MB。它不是实体车贴的印刷施工文件。

单张导入：Tesla App 的 Creations → Wrap → Upload。
U 盘导入：将一个 USB 批次中的 Wraps 文件夹放到 U 盘根目录。
每次最多 10 张；换批次时替换 Wraps 中的图片，不要把多批次合在一起。
在车机 Toybox → Paint Shop → Wraps 中选择。App 和 USB 各最多 10 张。

制作包每个编号对应：concept.png 为 AI 整车概念效果，qa.png 为实际导出图检查页，
Wraps/ 下为可导入 PNG，source-master.png 和 sources/ 是原画与分侧稿。
prompts.json / source-refinements.json / concept-refinement.json 记录创作和修订，meta.json 记录设计主题。
概念图为 AI 展示。网站 3D 把外壳分为 20 个面板：四门等比展示同款原画的精确导出裁片，
不加官方轮廓蒙版，以保持人脸比例；其余装饰面板读取 PNG。下载文件仍是官方模板展开图。
社区模型的面板位置、接缝和曲面显示可能与车机不同，最终兼容性及效果需在车辆中确认。
AI 原画按实际生成尺寸保存，没有将低分辨率放大后宣称为原生高分辨率。

官方模板与导入说明：https://github.com/teslamotors/custom-wraps
在线预览：https://qianyangpeng.github.io/itasha/
个人非商业同人设计收藏，角色与品牌属于各自权利人。

G01_Ningguang — 凝光 / 玉阙金绣
G02_Raiden — 雷电影 / 紫电御织
G03_YaeMiko — 八重神子 / 绯樱神乐
G04_Ganyu — 甘雨 / 霜华云锦
G05_Keqing — 刻晴 / 紫霆流金
G06_HuTao — 胡桃 / 夜梅蝶宴
G07_Zhongli — 钟离 / 琥珀契约
G08_Xiao — 魈 / 碧羽夜巡
G09_Ayaka — 神里绫华 / 银椿雪舞
G10_Kazuha — 枫原万叶 / 枫织流云
G11_Yoimiya — 宵宫 / 花火锦祭
G12_Kokomi — 珊瑚宫心海 / 珊瑚珠庭
G13_Furina — 芙宁娜 / 水幕华章
G14_Neuvillette — 那维莱特 / 潮汐庭章
G15_Navia — 娜维娅 / 金玫瑰沙龙
G16_Diluc — 迪卢克 / 赤夜典藏
G17_Tartaglia — 达达利亚 / 寒潮假面
G18_Venti — 温迪 / 翠羽诗章
G19_Albedo — 阿贝多 / 白垩金工
G20_Eula — 优菈 / 冰蓝华尔兹